﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{

    //to notify form1 back you need instance of Mydelegate class (as event in Form2) with a different name to do same work as one in form 1
    public partial class Form2 : Form
    {
        //public event MyDelegate NotifyParentEvent;
        //
        public event MyDelegate NotifyParentEvent2;
        public int ii;      

        public Form2() //ctpor
        {
            InitializeComponent();
            ii = 0;
        }

        public void UpdateTxtOnForm2(int input) //called by Parent (Form 1) using event
        {
            textBox1.Text = "i received from Parent: " + input.ToString();           
        }

        private void button1_Click(object sender, EventArgs e) //raises event 2
        {
            ii = 1;
            NotifyParentEvent2(ii);
        }
    }
}
