﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        //delegate way: overrides old link when new one is built
        //public delegate MyDelegate form2Delegate;


        // public delegate needs to be created in solution (ex: public delegate void buttonDel();)

        // for parent form to hear child class/form create event (ex: public event buttonDel myevent; ) with delegate from line above in public variables, then raise this event wherever (ex: in button1_click body)
        // parent will need to be subscribed to event when it creates instance of class/form to execute one of its methods (ex: myGroup myG = new myGroup; myG.myevent += new buttonDel(this.Listener);)

        //for child class/form to hear parent: create create event (ex: public event buttonDel ChildActionEvent; ) with delegate from line above in public variables; then raise this event wherever (ex: in button1_click body)
        // parent will need to be subscribed to event when it creates instance of class/form to execute one of methods of that class/form (ex: myGroup myG = new myGroup; ChildActionEvent += new buttonDel(myG.mess);)

        public event MyDelegate ChildActionEvent;
        public int i;


        public Form1()
        {

            InitializeComponent();
            i = 0;
        }
        

        private void button2_Click(object sender, EventArgs e) //loading child 
        {
            Form2 F2 = new Form2();
            ChildActionEvent += new MyDelegate(F2.UpdateTxtOnForm2);  //link
            F2.Show();            

            F2.NotifyParentEvent2 += new MyDelegate(F2_NotifyParentEvent2); //return message from Child (Form2) to Parent (Form1)           
        }

       
        private void button1_Click(object sender, EventArgs e) //sending data
        {
            i = i + 1;
            ChildActionEvent(i);  // raises event for things to update on Child (form2) 

            textBox1.Text = "Update #" + i.ToString();
        }

        //
        void F2_NotifyParentEvent2(int input)
        {           
            textBox1.Text = input + ". It was a pain!!!";
        }
    }


}
